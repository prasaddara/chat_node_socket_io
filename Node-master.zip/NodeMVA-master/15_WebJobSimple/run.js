
setInterval(function(){
	console.log("Repeatedly calling this function");
},5000);